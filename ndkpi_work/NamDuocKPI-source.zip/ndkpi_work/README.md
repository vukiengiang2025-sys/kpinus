<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/ee8ce97a-de83-4391-88a2-ac0d5876e1a1

## Run Locally

**Prerequisites:**  [Android Studio](https://developer.android.com/studio)


1. Open Android Studio
2. Select **Open** and choose the directory containing this project
3. Allow Android Studio to fix any incompatibilities as it imports the project.
4. Create a file named `.env` in the project directory and set `GEMINI_API_KEY` in that file to your Gemini API key (see `.env.example` for an example)
5. Remove this line from the app's `build.gradle.kts` file: `signingConfig = signingConfigs.getByName("debugConfig")`
6. Run the app on an emulator or physical device
7. If you have already published your app in AI Studio, please [request upload key reset](https://support.google.com/googleplay/android-developer/answer/9842756#zippy=%2Crequest-an-upload-key-reset) in Google Play Console.

## Nam Dược KPI v2

Phiên bản nâng cấp giữ nguyên công thức KPI lõi và bổ sung:

- Dự báo doanh số cuối tháng theo tốc độ bán thực tế.
- KPI Gap → Action: chuyển khoảng thiếu doanh số, bao phủ và SKU thành hành động cụ thể.
- Daily Action Plan: giao các gợi ý thành nhiệm vụ ưu tiên cao ngay trên Dashboard.
- Giao diện sáng/tối theo thiết bị và điều hướng gọn hơn.

## Build APK debug

```bash
./gradlew assembleDebug
```

APK đầu ra nằm tại `app/build/outputs/apk/debug/app-debug.apk`. Android SDK, `local.properties`, keystore và các thư mục build là file môi trường, không commit lên GitHub.
